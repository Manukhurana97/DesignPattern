package enums;

public enum Ingredient {
	WATER,
	COFFEE_BEANS,
	MILK,
	SUGER,
	CARAMEL_SYRUP,
	WIPPING_CREAM;
}	