package enums;

public enum CoffeeType {
    ESPRESSO,
    LATTE,
    CAPPUCCINO;

}
