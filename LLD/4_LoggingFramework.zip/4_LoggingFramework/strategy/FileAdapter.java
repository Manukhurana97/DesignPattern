package strategy;

import entities.LogMessage;
import formatter.LogFormat;
import formatter.TextFormat;

public class FileAdapter implements LogAdapter {

    private LogFormat formatter;

    public FileAdapter() {
        formatter = new TextFormat();
    }

    public void append(LogMessage logMessage) {
        System.out.println("Console: "+formatter.format(logMessage));
    }
}