package strategy;


import entities.LogMessage;
import formatter.LogFormat;
import formatter.TextFormat;

public class ConsoleAdapter implements LogAdapter {

    private LogFormat formatter;

    public ConsoleAdapter() {
        formatter = new TextFormat();
    }

    public void append(LogMessage logMessage) {
        System.out.println("Console: "+formatter.format(logMessage));
    }


}