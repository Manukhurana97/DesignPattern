package formatter;

import entities.LogMessage;

public class TextFormat implements LogFormat {

    public String format(LogMessage message) {
        return String.format("%s [%s] %s - %s - %s:%s\n", message.getTimeStamp(), message.getThread(), message.getLevel(), message.getName(), message.getDescription());

    }
}
